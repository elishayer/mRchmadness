## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(mRchmadness)

## ---- eval = FALSE-------------------------------------------------------
#  games.2018 = scrape.game.results(2018)

## ---- eval = FALSE-------------------------------------------------------
#  pred.pop.2018 = scrape.population.distribution(2018)

## ------------------------------------------------------------------------
head(games.men.2018)
head(pred.pop.men.2018)

## ------------------------------------------------------------------------
head(teams.men)

## ------------------------------------------------------------------------
set.seed(1)
prob.matrix = bradley.terry(games = games.men.2018)
prob.matrix["153", "150"]

## ------------------------------------------------------------------------
head(pred.538.men.2018)

## ------------------------------------------------------------------------
head(bracket.men.2018)

## ----dpi=150,fig.height=6,fig.width=8,out.height="500px",out.width="700px"----
set.seed(2018)
outcome = sim.bracket(bracket.empty = bracket.men.2018,
  prob.matrix = prob.matrix)
draw.bracket(bracket.empty = bracket.men.2018, bracket.filled = outcome)

## ----dpi=150,fig.height=6,fig.width=8,out.height="500px",out.width="700px"----
set.seed(42)
my.bracket = find.bracket(bracket.empty = bracket.men.2018,
  prob.matrix = prob.matrix, num.candidates = 100, num.sims = 1000,
  criterion = "win", pool.size = 30, bonus.round = c(1, 2, 4, 8, 16, 32),
  bonus.seed = rep(0, 16), bonus.combine = "add")
draw.bracket(bracket.empty = bracket.men.2018, bracket.filled = my.bracket)

## ------------------------------------------------------------------------
set.seed(8675309)
test = test.bracket(bracket.empty = bracket.men.2018,
  bracket.picks = my.bracket, prob.matrix = prob.matrix, pool.size = 30,
  num.sims = 1000, bonus.round = c(1, 2, 4, 8, 16, 32),
  bonus.seed = rep(0, 16), bonus.combine = "add")
hist(test$score, breaks = 20)
hist(test$percentile, breaks = 20)
mean(test$win)

