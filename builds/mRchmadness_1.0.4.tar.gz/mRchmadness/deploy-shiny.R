
# Packages needs to be installed locally from GitHub so that shinyapps.io
# knows which package to install on the server.
devtools::install_github('elishayer/mRchmadness')

rsconnect::setAccountInfo(name = 'saberpowers',
  token = '12C82F6E1ED154D46FEF2DEDF52A7914',
  secret = 'MFcyJEzDvg37HullT9b34anMnevH3jRkXoY2790P')

rsconnect::deployApp('inst/shinyApp', appName = 'mRchmadness')

