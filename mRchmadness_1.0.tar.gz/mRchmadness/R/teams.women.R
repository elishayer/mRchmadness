#' @name teams.women
#' @title NCAA Women's Basketball Teams
#' @description This dataset the names of each team in NCAA Women's
#'   Basketball from ESPN and their ESPN team id
#' @format data frame with 413 rows and 4 variables
#' @source \url{http://www.espn.com/womens-college-basketball/teams}
NULL
