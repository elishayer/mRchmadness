# mRchmadness
NCAA men's basketball data scraping and bracketology R package

## Installation

```{r}
devtools::install_github("elishayer/mRchmadness")
```
